const api = (typeof browser !== 'undefined' ? browser : chrome);

const DEFAULT_SETTINGS = {
    enabled: true,
    theme: 'light', // Новая настройка
    delay: 2.5,
    keys: {
        speedUp: ']', speedDown: '[', reset: '\\', pip: 'p', zoom: 'z', screenshot: 's'
    }
};

document.addEventListener('DOMContentLoaded', () => {
    // UI Elements
    const els = {
        body: document.body,
        themeBtn: document.getElementById('theme-toggle'),
        themeIcon: document.querySelector('.theme-icon'),
        enabled: document.getElementById('enabled-toggle'),
        delaySlider: document.getElementById('delay-slider'),
        delayValue: document.getElementById('delay-value'),
        keys: {
            speedUp: document.getElementById('btn-speed-up'),
            speedDown: document.getElementById('btn-speed-down'),
            reset: document.getElementById('btn-speed-reset'),
            pip: document.getElementById('btn-pip'),
            zoom: document.getElementById('btn-zoom'),
            screenshot: document.getElementById('btn-screenshot')
        }
    };

    let currentSettings = { ...DEFAULT_SETTINGS };

    // --- LOGIC ---

    api.storage.local.get(null, (items) => {
        currentSettings = {
            ...DEFAULT_SETTINGS,
            ...items,
            keys: { ...DEFAULT_SETTINGS.keys, ...(items.keys || {}) }
        };
        updateUI();
        applyTheme(currentSettings.theme);
    });

    function updateUI() {
        if (!els.enabled) return;
        
        els.enabled.checked = currentSettings.enabled;
        els.delaySlider.value = currentSettings.delay;
        els.delayValue.textContent = currentSettings.delay + "s";

        Object.keys(els.keys).forEach(keyName => {
            const btn = els.keys[keyName];
            if (btn) {
                btn.textContent = formatKey(currentSettings.keys[keyName]);
                btn.classList.remove('recording');
            }
        });
    }

    // THEME LOGIC
    function applyTheme(theme) {
        els.body.setAttribute('data-theme', theme);
        els.themeIcon.textContent = theme === 'light' ? '🌙' : '☀️';
    }

    els.themeBtn.addEventListener('click', () => {
        const newTheme = currentSettings.theme === 'light' ? 'dark' : 'light';
        currentSettings.theme = newTheme;
        applyTheme(newTheme);
        saveSettings();
    });

    // HELPERS
    function formatKey(key) {
        if (!key) return "Set";
        if (key === ' ') return 'Space';
        if (key.length === 1) return key.toUpperCase();
        return key.replace('Arrow', '');
    }

    function saveSettings() {
        api.storage.local.set(currentSettings);
    }

    // EVENT LISTENERS
    els.enabled.addEventListener('change', () => {
        currentSettings.enabled = els.enabled.checked;
        saveSettings();
    });

    els.delaySlider.addEventListener('input', () => {
        els.delayValue.textContent = els.delaySlider.value + "s";
        currentSettings.delay = parseFloat(els.delaySlider.value);
        saveSettings();
    });

    // KEY BINDING
    Object.keys(els.keys).forEach(actionName => {
        const btn = els.keys[actionName];
        if (!btn) return;

        btn.addEventListener('click', () => {
            btn.blur();
            btn.textContent = '...';
            btn.classList.add('recording');

            const recordHandler = (event) => {
                event.preventDefault();
                event.stopPropagation();
                if (['Shift', 'Control', 'Alt', 'Meta', 'Command', 'Option'].includes(event.key)) return;

                currentSettings.keys[actionName] = event.key;
                window.removeEventListener('keydown', recordHandler, true);
                updateUI();
                saveSettings();
            };
            window.addEventListener('keydown', recordHandler, { capture: true, once: true });
        });
    });
    
    // FOOTER LINK (External)
    const miraiLink = document.querySelector('.mirai-link');
    miraiLink.addEventListener('click', (e) => {
        e.preventDefault();
        const url = e.target.href;
        if (typeof browser !== 'undefined') {
            browser.tabs.create({ url: url });
        } else {
            chrome.tabs.create({ url: url });
        }
    });
});
