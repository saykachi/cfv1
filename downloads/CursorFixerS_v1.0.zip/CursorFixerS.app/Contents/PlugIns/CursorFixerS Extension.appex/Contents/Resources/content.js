const api = (typeof browser !== 'undefined' ? browser : chrome);

let cursorTimer = null;
let toastTimeout;
let lastX = 0, lastY = 0;

let state = {
    enabled: true,
    delay: 2500,
    keys: {
        speedUp: ']', speedDown: '[', reset: '\\', pip: 'p', zoom: 'z', screenshot: 's'
    }
};

const ZOOM_MODES = ['contain', 'cover', 'scale'];
let currentZoomIndex = 0;

const ICONS = {
    speed: `<svg viewBox="0 0 24 24"><path d="M20.38 8.57l-1.23 1.85a8 8 0 0 1-.22 7.58H5.07A8 8 0 0 1 15.58 6.85l1.85-1.23A10 10 0 0 0 3.35 19a2 2 0 0 0 1.72 1h13.85a2 2 0 0 0 1.74-1 10 10 0 0 0-.27-10.44zm-9.79 6.84a2 2 0 0 0 2.83 0l5.66-8.49-8.49 5.66a2 2 0 0 0 0 2.83z"/></svg>`,
    pip: `<svg viewBox="0 0 24 24"><path d="M19 11h-8v6h8v-6zm4 8V4.98C23 3.88 22.1 3 21 3H3c-1.1 0-2 .88-2 1.98V19c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2zm-2 .02H3V4.97h18v14.05z"/></svg>`,
    reset: `<svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm5 11h-4v4h-2v-4H7v-2h4V7h2v4h4v2z"/></svg>`,
    zoom: `<svg viewBox="0 0 24 24"><path d="M15 3l2.3 2.3-2.89 2.87 1.42 1.42L18.7 6.7 21 9V3zM3 9l2.3-2.3 2.87 2.89 1.42-1.42L6.7 5.3 9 3H3zm6 12l-2.3-2.3 2.89-2.87-1.42-1.42L5.3 17.3 3 15v6h6zm12-6l-2.3 2.3-2.87-2.89-1.42 1.42 2.89 2.87L15 21h6z"/></svg>`,
    camera: `<svg viewBox="0 0 24 24"><path d="M9 3L7.17 5H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2h-3.17L15 3H9zm3 15c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5z"/></svg>`
};

function updateState(items) {
    if (!items) return;
    if (items.enabled !== undefined) state.enabled = items.enabled;
    if (items.delay !== undefined) state.delay = items.delay * 1000;
    if (items.keys) state.keys = { ...state.keys, ...items.keys };

    if (!state.enabled) forceShowCursor();
    else resetTimer();
}

api.storage.local.get(null, updateState);

api.storage.onChanged.addListener((changes, area) => {
    if (area === 'local') {
        const newItems = {};
        for (let key in changes) {
            newItems[key] = changes[key].newValue;
        }
        updateState(newItems);
    }
});

const hudContainer = document.createElement('div');
hudContainer.className = 'hud-toast';
hudContainer.innerHTML = `<div class="hud-icon"></div><div class="hud-text"></div>`;

function showHud(iconSvg, text) {
    const target = document.fullscreenElement || document.webkitFullscreenElement || document.body;
    if (hudContainer.parentElement !== target) target.appendChild(hudContainer);
    
    hudContainer.querySelector('.hud-icon').innerHTML = iconSvg;
    hudContainer.querySelector('.hud-text').textContent = text;
    hudContainer.classList.remove('visible');
    requestAnimationFrame(() => hudContainer.classList.add('visible'));
    clearTimeout(toastTimeout);
    toastTimeout = setTimeout(() => hudContainer.classList.remove('visible'), 1500);
}

function isFullscreen() {
    return document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement;
}

function hideCursor() {
    if (!state.enabled || !isFullscreen()) return;
    document.body.classList.add('cursor-hidden');
}

function forceShowCursor() {
    document.body.classList.remove('cursor-hidden');
    clearTimeout(cursorTimer);
}

function resetTimer() {
    document.body.classList.remove('cursor-hidden');
    clearTimeout(cursorTimer);
    if (state.enabled && isFullscreen()) cursorTimer = setTimeout(hideCursor, state.delay);
}

window.addEventListener('mousemove', (e) => {
    if (e.clientX === lastX && e.clientY === lastY) return;
    lastX = e.clientX; lastY = e.clientY;
    resetTimer();
}, true);

document.addEventListener('fullscreenchange', () => isFullscreen() ? resetTimer() : forceShowCursor());
document.addEventListener('webkitfullscreenchange', () => isFullscreen() ? resetTimer() : forceShowCursor());

function findActiveVideo() {
    const videos = document.querySelectorAll('video');
    if (!videos.length) return null;
    for (let v of videos) { if (!v.paused && v.readyState > 2) return v; }
    return videos[0];
}

function cleanSpeed(val) { return parseFloat(val.toFixed(2)); }

function takeScreenshot(video) {
    try {
        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth; canvas.height = video.videoHeight;
        canvas.getContext('2d').drawImage(video, 0, 0);
        const link = document.createElement('a');
        link.download = `snap_${Date.now()}.jpg`;
        link.href = canvas.toDataURL('image/jpeg', 0.95);
        link.click();
        showHud(ICONS.camera, "Saved");
    } catch (e) { showHud(ICONS.camera, "Blocked"); }
}

document.addEventListener('keydown', (e) => {
    if (['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName) || document.activeElement.isContentEditable) return;

    const pressed = e.key;
    const pressedLower = e.key.toLowerCase();
    const video = findActiveVideo();
    
    if (!video) return;

    const is = (binding) => binding && (pressed === binding || pressedLower === binding.toLowerCase());

    if (is(state.keys.speedUp)) {
        video.playbackRate = Math.min(cleanSpeed(video.playbackRate + 0.25), 5.0);
        showHud(ICONS.speed, `${video.playbackRate}x`);
    }
    else if (is(state.keys.speedDown)) {
        video.playbackRate = Math.max(cleanSpeed(video.playbackRate - 0.25), 0.25);
        showHud(ICONS.speed, `${video.playbackRate}x`);
    }
    else if (is(state.keys.reset)) {
        video.playbackRate = 1.0;
        showHud(ICONS.reset, "Normal");
    }
    else if (is(state.keys.pip)) {
        if (document.pictureInPictureElement) document.exitPictureInPicture();
        else if (document.pictureInPictureEnabled) video.requestPictureInPicture();
    }
    else if (is(state.keys.zoom)) {
        currentZoomIndex = (currentZoomIndex + 1) % ZOOM_MODES.length;
        const mode = ZOOM_MODES[currentZoomIndex];
        if (mode === 'scale') { video.style.transform = "scale(1.2)"; showHud(ICONS.zoom, "Zoom 1.2x"); }
        else { video.style.transform = "none"; video.style.objectFit = mode; showHud(ICONS.zoom, mode); }
    }
    else if (is(state.keys.screenshot)) {
        takeScreenshot(video);
    }
});
