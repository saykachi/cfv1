const api = (typeof browser !== 'undefined' ? browser : chrome);

const DEFAULT_SETTINGS = {
    enabled: true,
    autoSkip: true,
    theme: 'light',
    delay: 2.5,
    keys: { speedUp: ']', speedDown: '[', reset: '\\', pip: 'p', zoom: 'z', screenshot: 's' }
};

document.addEventListener('DOMContentLoaded', () => {
    // Получаем элементы безопасно
    const getEl = (id) => document.getElementById(id);
    
    const els = {
        body: document.body,
        themeBtn: getEl('theme-toggle'),
        themeIcon: document.querySelector('.theme-icon'),
        enabled: getEl('enabled-toggle'),
        autoSkip: getEl('autoskip-toggle'),
        delaySlider: getEl('delay-slider'),
        delayValue: getEl('delay-value'),
        tabBtns: document.querySelectorAll('.tab-btn'),
        tabViews: document.querySelectorAll('.tab-view'),
        keys: {
            speedUp: getEl('btn-speed-up'),
            speedDown: getEl('btn-speed-down'),
            reset: getEl('btn-speed-reset'),
            pip: getEl('btn-pip'),
            zoom: getEl('btn-zoom'),
            screenshot: getEl('btn-screenshot')
        }
    };

    let currentSettings = { ...DEFAULT_SETTINGS };

    // --- ЛОГИКА ТАБОВ (ПЕРЕКЛЮЧЕНИЕ) ---
    // Выносим наверх, чтобы работало сразу
    if (els.tabBtns) {
        els.tabBtns.forEach(btn => {
            btn.addEventListener('click', (e) => {
                // 1. Убираем активный класс у всех кнопок
                els.tabBtns.forEach(b => b.classList.remove('active'));
                // 2. Убираем активный класс у всех страниц
                els.tabViews.forEach(v => v.classList.remove('active'));
                
                // 3. Активируем нажатую кнопку
                btn.classList.add('active');
                
                // 4. Показываем нужную страницу
                const targetId = btn.getAttribute('data-target');
                const targetView = document.getElementById(targetId);
                if (targetView) targetView.classList.add('active');
            });
        });
    }

    // --- ЗАГРУЗКА НАСТРОЕК ---
    api.storage.local.get(null, (items) => {
        currentSettings = { ...DEFAULT_SETTINGS, ...items, keys: { ...DEFAULT_SETTINGS.keys, ...(items.keys || {}) } };
        updateUI();
        applyTheme(currentSettings.theme);
    });

    function updateUI() {
        if (els.enabled) els.enabled.checked = currentSettings.enabled;
        if (els.autoSkip) els.autoSkip.checked = currentSettings.autoSkip;
        if (els.delaySlider) els.delaySlider.value = currentSettings.delay;
        if (els.delayValue) els.delayValue.textContent = currentSettings.delay + "s";

        Object.keys(els.keys).forEach(keyName => {
            const btn = els.keys[keyName];
            if (btn) {
                btn.textContent = formatKey(currentSettings.keys[keyName]);
                btn.classList.remove('recording');
            }
        });
    }

    function formatKey(key) {
        if (!key) return "Set";
        if (key === ' ') return 'Space';
        if (key.length === 1) return key.toUpperCase();
        return key.replace('Arrow', '');
    }

    function applyTheme(theme) {
        els.body.setAttribute('data-theme', theme);
        if(els.themeIcon) els.themeIcon.textContent = theme === 'light' ? '🌙' : '☀️';
    }

    function saveSettings() {
        api.storage.local.set(currentSettings);
    }

    // --- СЛУШАТЕЛИ СОБЫТИЙ ---
    if(els.themeBtn) els.themeBtn.addEventListener('click', () => {
        currentSettings.theme = currentSettings.theme === 'light' ? 'dark' : 'light';
        applyTheme(currentSettings.theme);
        saveSettings();
    });

    if(els.enabled) els.enabled.addEventListener('change', () => {
        currentSettings.enabled = els.enabled.checked;
        saveSettings();
    });

    if(els.autoSkip) els.autoSkip.addEventListener('change', () => {
        currentSettings.autoSkip = els.autoSkip.checked;
        saveSettings();
    });

    if(els.delaySlider) els.delaySlider.addEventListener('input', () => {
        els.delayValue.textContent = els.delaySlider.value + "s";
        currentSettings.delay = parseFloat(els.delaySlider.value);
        saveSettings();
    });

    // Бинды клавиш
    Object.keys(els.keys).forEach(actionName => {
        const btn = els.keys[actionName];
        if (!btn) return;
        btn.addEventListener('click', () => {
            btn.blur(); btn.textContent = '...'; btn.classList.add('recording');
            const recordHandler = (event) => {
                event.preventDefault(); event.stopPropagation();
                if (['Shift', 'Control', 'Alt', 'Meta', 'Command', 'Option'].includes(event.key)) return;
                currentSettings.keys[actionName] = event.key;
                window.removeEventListener('keydown', recordHandler, true);
                updateUI(); saveSettings();
            };
            window.addEventListener('keydown', recordHandler, { capture: true, once: true });
        });
    });
    
    const miraiLink = document.querySelector('.mirai-link');
    if(miraiLink) {
        miraiLink.addEventListener('click', (e) => {
            e.preventDefault();
            (typeof browser !== 'undefined' ? browser : chrome).tabs.create({ url: e.target.href });
        });
    }
});
