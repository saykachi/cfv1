const api = (typeof browser !== 'undefined' ? browser : chrome);

// CONFIG
const SPEEDS = [0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0, 2.25, 2.5, 3.0, 3.5, 4.0, 5.0];
const ZOOM_MODES = ['contain', 'cover', 'scale'];
let state = { enabled: true, autoSkip: true, delay: 2500, keys: { speedUp: ']', speedDown: '[', reset: '\\', pip: 'p', zoom: 'z', screenshot: 's' } };
let cursorTimer, toastTimeout, lastX = 0, lastY = 0, currentZoomIndex = 0;

// ICONS
const ICONS = {
    speed: '<svg viewBox="0 0 24 24"><path d="M20.38 8.57l-1.23 1.85a8 8 0 0 1-.22 7.58H5.07A8 8 0 0 1 15.58 6.85l1.85-1.23A10 10 0 0 0 3.35 19a2 2 0 0 0 1.72 1h13.85a2 2 0 0 0 1.74-1 10 10 0 0 0-.27-10.44zm-9.79 6.84a2 2 0 0 0 2.83 0l5.66-8.49-8.49 5.66a2 2 0 0 0 0 2.83z"/></svg>',
    pip: '<svg viewBox="0 0 24 24"><path d="M19 11h-8v6h8v-6zm4 8V4.98C23 3.88 22.1 3 21 3H3c-1.1 0-2 .88-2 1.98V19c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2zm-2 .02H3V4.97h18v14.05z"/></svg>',
    reset: '<svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm5 11h-4v4h-2v-4H7v-2h4V7h2v4h4v2z"/></svg>',
    zoom: '<svg viewBox="0 0 24 24"><path d="M15 3l2.3 2.3-2.89 2.87 1.42 1.42L18.7 6.7 21 9V3zM3 9l2.3-2.3 2.87 2.89 1.42-1.42L6.7 5.3 9 3H3zm6 12l-2.3-2.3 2.89-2.87-1.42-1.42L5.3 17.3 3 15v6h6zm12-6l-2.3 2.3-2.87-2.89-1.42 1.42 2.89 2.87L15 21h6z"/></svg>',
    camera: '<svg viewBox="0 0 24 24"><path d="M9 3L7.17 5H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2h-3.17L15 3H9zm3 15c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5z"/></svg>',
    skip: '<svg viewBox="0 0 24 24"><path d="M4 18l8.5-6L4 6v12zm9-12v12l8.5-6L13 6z"/></svg>'
};

// SETTINGS & HUD
const updateState = (items) => {
    if (items?.enabled !== undefined) state.enabled = items.enabled;
    if (items?.autoSkip !== undefined) state.autoSkip = items.autoSkip;
    if (items?.delay !== undefined) state.delay = items.delay * 1000;
    if (items?.keys) state.keys = { ...state.keys, ...items.keys };
    state.enabled ? resetTimer() : forceShowCursor();
};
api.storage.local.get(null, updateState);
api.storage.onChanged.addListener((c) => { const n={}; for(let k in c)n[k]=c[k].newValue; updateState(n); });

const hud = document.createElement('div'); hud.className = 'hud-toast'; hud.innerHTML = `<div class="hud-icon"></div><div class="hud-text"></div>`;
const showHud = (icon, text) => {
    const t = document.fullscreenElement || document.webkitFullscreenElement || document.body;
    if(hud.parentElement!==t) t.appendChild(hud);
    hud.querySelector('.hud-icon').innerHTML = icon; hud.querySelector('.hud-text').textContent = text;
    hud.classList.remove('visible'); void hud.offsetWidth; hud.classList.add('visible');
    clearTimeout(toastTimeout); toastTimeout = setTimeout(() => hud.classList.remove('visible'), 1200);
};

// CURSOR
const isFullscreen = () => document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement;
const hideCursor = () => { if (state.enabled && isFullscreen()) document.body.classList.add('cursor-hidden'); };
const forceShowCursor = () => { document.body.classList.remove('cursor-hidden'); clearTimeout(cursorTimer); };
const resetTimer = () => {
    document.body.classList.remove('cursor-hidden'); clearTimeout(cursorTimer);
    if (state.enabled && isFullscreen()) cursorTimer = setTimeout(hideCursor, state.delay);
};
window.addEventListener('mousemove', (e) => {
    if (Math.abs(e.clientX - lastX) < 2 && Math.abs(e.clientY - lastY) < 2) return;
    lastX = e.clientX; lastY = e.clientY; resetTimer();
}, { passive: true });
['fullscreenchange', 'webkitfullscreenchange'].forEach(evt => document.addEventListener(evt, () => isFullscreen() ? resetTimer() : forceShowCursor(), { passive: true }));

const getAllVideos = (root = document) => {
    let videos = Array.from(root.querySelectorAll('video'));
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
    let node = walker.nextNode();
    while (node) {
        if (node.shadowRoot) videos = videos.concat(getAllVideos(node.shadowRoot));
        node = walker.nextNode();
    }
    return videos;
};

const findActiveVideo = () => {
    const videos = getAllVideos();
    if (!videos.length) return null;
    let maxArea = 0, best = null;
    for (let v of videos) {
        const r = v.getBoundingClientRect();
        if (r.width * r.height > maxArea && v.style.display !== 'none') { maxArea = r.width * r.height; best = v; }
    }
    return best;
};

// === YOUTUBE TERMINATOR (SPECIAL LOGIC) ===
// Эта функция работает исключительно с YouTube API и DOM
const initYouTubeObserver = () => {
    // Ждем появления плеера
    const target = document.querySelector('.html5-video-player');
    if (!target) return;

    // Функция мгновенного уничтожения
    const killYtAd = () => {
        // Проверка: Идет ли реклама?
        if (target.classList.contains('ad-showing') || target.classList.contains('ad-interrupting')) {
            const video = document.querySelector('video');
            if (video) {
                video.muted = true;
                video.playbackRate = 16.0; // Максимальное ускорение
                // Прыгаем в конец, но оставляем долю секунды, чтобы YT засчитал просмотр и не завис
                if (Number.isFinite(video.duration)) {
                    video.currentTime = video.duration;
                }
            }
            
            // Нажимаем ВСЕ возможные кнопки пропуска
            const btns = document.querySelectorAll('.ytp-ad-skip-button, .ytp-ad-skip-button-modern, .videoAdUiSkipButton, .ytp-skip-ad-button');
            btns.forEach(b => b.click());
            
            // Жмем на "Закрыть баннер"
            const overlays = document.querySelectorAll('.ytp-ad-overlay-close-button');
            overlays.forEach(b => b.click());
            
            console.log('Cursor Fixer: YT Ad Killed');
        }
    };

    // Создаем наблюдателя, который реагирует на изменение КЛАССОВ плеера
    // Это работает быстрее, чем setInterval
    const observer = new MutationObserver((mutations) => {
        for (const m of mutations) {
            if (m.attributeName === 'class') {
                killYtAd();
            }
        }
    });

    observer.observe(target, { attributes: true });
    
    // На всякий случай запускаем проверку раз в секунду (для баннеров)
    setInterval(killYtAd, 1000);
};

// Запускаем наблюдателя YouTube, если мы на этом сайте
if (window.location.hostname.includes('youtube.com')) {
    const checkYtLoaded = setInterval(() => {
        if (document.querySelector('.html5-video-player')) {
            clearInterval(checkYtLoaded);
            initYouTubeObserver();
        }
    }, 500);
}


// === UNIVERSAL SKIPPER (OTHER SITES) ===

const getSafeParent = (video) => {
    let p = video.parentElement;
    while (p && p.tagName !== 'BODY') {
        const r = p.getBoundingClientRect();
        if (r.width >= video.offsetWidth && r.height >= video.offsetHeight) return p;
        p = p.parentElement;
    }
    return video.parentElement || document.body;
};

// Сканер текста (игнорирует нашу кнопку)
const scanForAdText = (container) => {
    if (!container) return false;
    const clone = container.cloneNode(true);
    const ourBtn = clone.querySelector('.mirai-skip-wrapper');
    if (ourBtn) ourBtn.remove();
    
    const text = clone.innerText.toLowerCase();
    const keywords = ['реклама', 'пропустить', 'advertisement', 'skip ad', 'sponsored', 'спонсор'];
    
    if (keywords.some(k => text.includes(k))) return true;
    const hasBadLink = container.querySelector('a[href*="googleadservices"], iframe[src*="doubleclick"]');
    return !!hasBadLink;
};

const attachSkipButton = (video) => {
    // На YouTube наша кнопка не нужна, там работает Terminator
    if (window.location.hostname.includes('youtube.com')) return;

    if (video.offsetWidth < 200 || video.offsetHeight < 150) return;
    const container = getSafeParent(video);
    if (!container || container.querySelector('.mirai-skip-wrapper')) return;

    container.classList.add('mirai-video-container');

    const wrapper = document.createElement('div');
    wrapper.className = 'mirai-skip-wrapper';
    wrapper.innerHTML = `<div class="mirai-skip-btn">${ICONS.skip} <span>SKIP AD</span></div>`;
    container.appendChild(wrapper);
    const btn = wrapper.querySelector('.mirai-skip-btn');

    const checkAdStatus = () => {
        // SAFETY: Длинные видео (> 5 мин) - НЕ РЕКЛАМА
        if (video.duration && video.duration > 300) {
            wrapper.classList.remove('ad-detected');
            return;
        }

        let isAd = false;
        let confidence = 0;

        // Короткие видео (< 75 сек)
        if (video.duration && video.duration < 75 && Number.isFinite(video.duration)) {
            if (scanForAdText(container)) {
                isAd = true;
                confidence = 100;
            } else {
                isAd = true;
                confidence = 50; // Подозрение
            }
        }

        if (isAd) {
            wrapper.classList.add('ad-detected');
            // Auto-Skip ТОЛЬКО если 100% уверенность
            if (state.autoSkip && confidence === 100 && !video.paused && !video._isQueuedForSkip) {
                video._isQueuedForSkip = true;
                setTimeout(() => {
                    if (wrapper.classList.contains('ad-detected')) btn.click();
                    video._isQueuedForSkip = false;
                }, 800);
            }
        } else {
            wrapper.classList.remove('ad-detected');
        }
    };

    video.addEventListener('durationchange', checkAdStatus);
    video.addEventListener('loadedmetadata', checkAdStatus);
    video.addEventListener('play', checkAdStatus);
    setInterval(checkAdStatus, 1000);

    btn.addEventListener('click', (e) => {
        e.stopPropagation(); e.preventDefault(); e.stopImmediatePropagation();
        
        if (!isNaN(video.duration) && isFinite(video.duration)) {
            video.currentTime = video.duration;
        } else {
            video.playbackRate = 16.0; video.muted = true;
        }
        
        // Brute force click
        const p = container.parentElement || document.body;
        p.querySelectorAll('button, div[role="button"]').forEach(el => {
            const t = el.innerText.toLowerCase();
            if (t === 'skip' || t === 'skip ad' || t === 'пропустить') el.click();
        });
    });
};

// Запускаем инжектор (кроме YouTube)
setInterval(() => {
    if (!window.location.hostname.includes('youtube.com')) {
        const videos = getAllVideos();
        videos.forEach(attachSkipButton);
    }
}, 1000);

// ACTIONS & BINDINGS (Same)
const takeScreenshot = (video) => {
    try {
        const cvs = document.createElement('canvas'); cvs.width = video.videoWidth; cvs.height = video.videoHeight;
        cvs.getContext('2d').drawImage(video, 0, 0);
        const a = document.createElement('a'); a.download = `snap_${Date.now()}.jpg`; a.href = cvs.toDataURL('image/jpeg', 0.9);
        a.click(); showHud(ICONS.camera, "Saved");
    } catch { showHud(ICONS.camera, "Blocked"); }
};
const changeSpeed = (video, dir) => {
    let idx=0, min=Infinity; for(let i=0;i<SPEEDS.length;i++){ let d=Math.abs(video.playbackRate-SPEEDS[i]); if(d<min){min=d;idx=i;}}
    let n = dir==='up'?idx+1:idx-1; if(n<0)n=0; if(n>=SPEEDS.length)n=SPEEDS.length-1;
    video.playbackRate=SPEEDS[n]; showHud(ICONS.speed, `${SPEEDS[n]}x`);
};
document.addEventListener('keydown', (e) => {
    if (e.repeat || ['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName) || document.activeElement.isContentEditable) return;
    const k = e.key.toLowerCase(), b = state.keys;
    const m = (bd) => bd && bd.toLowerCase() === k;
    if (!Object.values(b).some(v => m(v))) return;
    const vid = findActiveVideo();
    if (!vid) return;
    if (m(b.speedUp)) changeSpeed(vid, 'up');
    else if (m(b.speedDown)) changeSpeed(vid, 'down');
    else if (m(b.reset)) { vid.playbackRate = 1.0; showHud(ICONS.reset, "Normal"); }
    else if (m(b.pip)) document.pictureInPictureElement ? document.exitPictureInPicture() : vid.requestPictureInPicture().catch(()=>{});
    else if (m(b.zoom)) {
        currentZoomIndex = (currentZoomIndex + 1) % ZOOM_MODES.length;
        const mode = ZOOM_MODES[currentZoomIndex];
        vid.style.transform = mode === 'scale' ? "scale(1.25)" : "none";
        vid.style.objectFit = mode === 'scale' ? "contain" : mode;
        showHud(ICONS.zoom, mode === 'contain' ? 'Normal' : (mode === 'scale' ? 'Zoom 1.25x' : 'Fill Screen'));
    }
    else if (m(b.screenshot)) takeScreenshot(vid);
}, { passive: false });
